<?php
$server="localhost";
$db="phpjasperxml";
$user="root";
$pass="user1";
$version="0.9d";
$pgport=5432;
$pchartfolder="./class/pchart2";
